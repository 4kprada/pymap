import csv
import json


FIELDS = ["ip", "port", "status"]


def export_json(results, filename):
    """Export scan results to JSON."""

    with open(filename, "w", encoding="utf-8") as file:
        json.dump(
            results,
            file,
            indent=4
        )


def export_csv(results, filename):
    """Export scan results to CSV."""

    with open(
        filename,
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=FIELDS
        )

        writer.writeheader()
        writer.writerows(results)