import socket
from concurrent.futures import ThreadPoolExecutor, as_completed


def check_port(ip, port, timeout=1.0):
    """Check whether a TCP port accepts a connection."""

    result = {
        "ip": ip,
        "port": port,
        "status": "unknown"
    }

    try:
        with socket.create_connection(
            (ip, port),
            timeout=timeout
        ):
            result["status"] = "open"

    except ConnectionRefusedError:
        result["status"] = "closed"

    except socket.timeout:
        result["status"] = "filtered_or_timeout"

    except OSError:
        result["status"] = "unreachable"

    return result


def scan_targets(targets, ports, timeout=1.0, workers=8):
    """Run TCP checks against explicitly authorised targets."""

    workers = max(1, min(workers, 32))
    results = []

    with ThreadPoolExecutor(max_workers=workers) as executor:

        futures = [
            executor.submit(check_port, ip, port, timeout)
            for ip in targets
            for port in ports
        ]

        for future in as_completed(futures):
            results.append(future.result())

    return sorted(
        results,
        key=lambda item: (item["ip"], item["port"])
    )