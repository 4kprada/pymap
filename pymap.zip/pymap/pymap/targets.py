import ipaddress


MAX_TARGETS = 256


def parse_target(target):
    """Parse and validate a single IP or CIDR range."""

    try:
        network = ipaddress.ip_network(target, strict=False)
    except ValueError:
        raise ValueError(f"Invalid IP address or CIDR: {target}")

    if network.version != 4:
        raise ValueError("Only IPv4 addresses are supported.")

    if network.num_addresses > MAX_TARGETS:
        raise ValueError(
            f"Target range exceeds maximum of {MAX_TARGETS} addresses."
        )

    if not (
        network.is_private
        or network.is_loopback
        or network.is_link_local
    ):
        raise ValueError("Only private, loopback and link-local targets allowed.")

    if network.prefixlen >= 31:
        addresses = list(network)
    else:
        addresses = list(network.hosts())

    return [str(address) for address in addresses]