import argparse
import sys

from pymap import __version__
from pymap.targets import parse_target
from pymap.scanner import scan_targets
from pymap.exporters import export_csv, export_json


def parse_ports(value):
    """Parse comma-separated TCP ports."""

    try:
        ports = sorted(set(int(p) for p in value.split(",")))
    except ValueError:
        raise argparse.ArgumentTypeError(
            "Ports must be comma-separated integers."
        )

    if not ports or any(p < 1 or p > 65535 for p in ports):
        raise argparse.ArgumentTypeError(
            "Ports must be between 1 and 65535."
        )

    return ports


def main():

    parser = argparse.ArgumentParser(
        prog="pymap",
        description="Python TCP network scanner"
    )

    parser.add_argument(
        "-t", "--target",
        required=True,
        help="IPv4 address or CIDR range"
    )

    parser.add_argument(
        "-p", "--ports",
        type=parse_ports,
        default=[22, 80, 443],
        help="Ports to scan (default: 22,80,443)"
    )

    parser.add_argument(
        "--timeout",
        type=float,
        default=1.0,
        help="Connection timeout in seconds"
    )

    parser.add_argument(
        "-w", "--workers",
        type=int,
        default=8,
        help="Concurrent workers (maximum 32)"
    )

    parser.add_argument(
        "--csv",
        help="Export results to CSV"
    )

    parser.add_argument(
        "--json",
        help="Export results to JSON"
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate targets without scanning"
    )

    parser.add_argument(
        "--i-have-authorization",
        action="store_true",
        help="Confirm you have permission to scan this target"
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"pymap {__version__}"
    )

    args = parser.parse_args()

    if not args.i_have_authorization:
        parser.error(
            "Authorisation confirmation required. "
            "Use --i-have-authorization."
        )

    if not 0 < args.timeout <= 10:
        parser.error("Timeout must be greater than 0 and at most 10.")

    if not 1 <= args.workers <= 32:
        parser.error("Workers must be between 1 and 32.")

    try:
        targets = parse_target(args.target)

        print(f"\npymap {__version__}")
        print(f"Targets: {len(targets)}")
        print(f"Ports: {args.ports}")

        if args.dry_run:
            print("\nDry run successful. No connections made.")
            return

        print("\nStarting TCP scan...\n")

        results = scan_targets(
            targets,
            args.ports,
            timeout=args.timeout,
            workers=args.workers
        )

        for result in results:
            print(
                f"{result['ip']}:{result['port']} "
                f"- {result['status']}"
            )

        if args.csv:
            export_csv(results, args.csv)
            print(f"\nCSV saved: {args.csv}")

        if args.json:
            export_json(results, args.json)
            print(f"\nJSON saved: {args.json}")

        print(f"\nCompleted {len(results)} checks.")

    except (ValueError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()