pymap



pymap is a lightweight Python-based TCP network scanner for authorised network diagnostics and lab environments.



Features

TCP port scanning

IPv4 address scanning

CIDR range support

Configurable ports

Configurable connection timeouts

Concurrent scanning

JSON export

CSV export

Command-line interface

Dry-run mode

Requirements

Python 3.10+

Linux (Kali Linux / Ubuntu)

No external runtime dependencies

Installation



Clone the repository:



bash

git clone https://github.com/4kprada/pymap.git

cd pymap



Usage



Show help:



bash

python3 -m pymap.cli --help





Show version:



bash

python3 -m pymap.cli --version





Validate a local target without scanning:



bash

python3 -m pymap.cli \\

&#x20; -t 127.0.0.1 \\

&#x20; --dry-run \\

&#x20; --i-have-authorization





Scan an authorised local target:



bash

python3 -m pymap.cli \\

&#x20; -t 127.0.0.1 \\

&#x20; -p 22,80,443 \\

&#x20; --i-have-authorization





Scan an authorised private CIDR range:



bash

python3 -m pymap.cli \\

&#x20; -t 192.168.1.0/24 \\

&#x20; -p 80,443 \\

&#x20; --i-have-authorization





Export results:



bash

python3 -m pymap.cli \\

&#x20; -t 127.0.0.1 \\

&#x20; -p 22,80,443 \\

&#x20; --csv results.csv \\

&#x20; --json results.json \\

&#x20; --i-have-authorization



Command-line arguments

Argument	Description

\-t, --target	IPv4 address or CIDR

\-p, --ports	TCP ports

\-w, --workers	Concurrent workers

\--timeout	Connection timeout

\--csv	CSV export

\--json	JSON export

\--dry-run	Validate without scanning

\--i-have-authorization	Confirm scanning permission

\--version	Display version

\-h, --help	Display help

Safety



pymap is designed for authorised network diagnostics.



The initial release:



Only accepts private, loopback and link-local IPv4 targets.

Limits target ranges to 256 addresses.

Limits concurrency to 32 workers.

Requires explicit authorisation confirmation.



The confirmation flag does not independently verify permission.



Project status



Version: 0.1.0



Status: Initial development



License



MIT License

